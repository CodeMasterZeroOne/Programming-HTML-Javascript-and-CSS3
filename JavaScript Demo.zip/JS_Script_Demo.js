// JavaScript source code
function reply() {
    alert("I'm fine, thanks.\nHow are you?");
}